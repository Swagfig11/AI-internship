This is a chatbot for predefined set of instructions.
It will tell us about the news and weather using free api's. We need to put the coordinates of the place as i have used free api's.
We can use comments and queries like,
Hello 
Hi
 whats the news?
 whats the weather? 
Thank You
use goodbye or bye to exit the program
~Swarad Gujarathi