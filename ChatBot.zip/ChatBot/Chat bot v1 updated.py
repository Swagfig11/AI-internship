import requests
from transformers import GPT2LMHeadModel, GPT2Tokenizer

# Load pre-trained model and tokenizer
model_name = 'gpt2'  # You can use 'gpt-3' if you have access
model = GPT2LMHeadModel.from_pretrained(model_name)
tokenizer = GPT2Tokenizer.from_pretrained(model_name)

# Set pad_token_id to eos_token_id
tokenizer.pad_token_id = tokenizer.eos_token_id

# Define the chatbot response function
def chatbot_response(user_input):
    user_input = user_input.lower()
    
    # Predefined rules for responding to greetings
    if 'hello' in user_input or 'hi' in user_input:
        return "Hello! How can I assist you today?"
    
    # Predefined rules for responding to thanks
    elif 'thank' in user_input:
        return "You're welcome! Do you have any other questions?"
    
    # Rule for weather information
    elif 'weather' in user_input:
        return get_weather()
    
    # Rule for news information
    elif 'news' in user_input:
        return get_news()
    
    # Rule for exiting the chatbot
    elif 'goodbye' in user_input or 'bye' in user_input:
        return "Goodbye! Have a great day!"
    
    # Default response using GPT-3
    else:
        return generate_response(user_input)

# Function to get weather information
def get_weather():
    latitude = 18.8667  # Latitude for Rajgurunagar, Pune
    longitude = 73.9    # Longitude for Rajgurunagar, Pune
    url = f'https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&current_weather=true'
    response = requests.get(url).json()
    weather = response['current_weather']
    temp = weather['temperature']
    wind_speed = weather['windspeed']
    return f"The current weather in Rajgurunagar, Pune is {temp}°C with a wind speed of {wind_speed} km/h."

# Function to get news information
def get_news():
    url = 'https://inshortsapi.vercel.app/news?category=all'
    response = requests.get(url).json()
    articles = response['data'][:5]  # Get top 5 news articles
    news = "\n".join([f"{i+1}. {article['title']}" for i, article in enumerate(articles)])
    return f"Here are the top news headlines:\n{news}"

# Function to generate response using GPT-3
def generate_response(prompt):
    inputs = tokenizer.encode(prompt, return_tensors='pt')
    attention_mask = inputs.ne(tokenizer.pad_token_id).long()
    outputs = model.generate(inputs, attention_mask=attention_mask, max_length=150, num_return_sequences=1, pad_token_id=tokenizer.eos_token_id)
    response = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=True)
    return response

# Main loop to keep the chatbot running
while True:
    user_query = input("Please enter your query: ")
    response = chatbot_response(user_query)
    print(response)
    if 'goodbye' in user_query.lower() or 'bye' in user_query.lower():
        break
