import pandas as pd
from surprise import Dataset, Reader, SVD
from surprise.model_selection import train_test_split, GridSearchCV
from surprise import accuracy

# Load the dataset
ratings = pd.read_csv(r"C:\Users\Dell\Desktop\Projects\Bollywood-Movie-Dataset-main\IMDB-Movie-Dataset(2023-1951).csv")

# Handle missing values
ratings.dropna(inplace=True)

# Define a reader with the rating scale
reader = Reader(rating_scale=(1, 5))

# Load the dataset into Surprise
data = Dataset.load_from_df(ratings[['movie_name', 'movie_id', 'rating']], reader)

# Split the data into training and testing sets
trainset, testset = train_test_split(data, test_size=0.25)

# Use the SVD algorithm with hyperparameter tuning
param_grid = {'n_epochs': [20, 30], 'lr_all': [0.005, 0.010], 'reg_all': [0.02, 0.1]}
gs = GridSearchCV(SVD, param_grid, measures=['rmse'], cv=3)
gs.fit(data)

algo = gs.best_estimator['rmse']

# Train the algorithm on the trainset
algo.fit(trainset)

# Predict ratings for the testset
predictions = algo.test(testset)

# Calculate RMSE
accuracy.rmse(predictions)

# Function to get movie recommendations
def get_recommendations(movie_name, num_recommendations=10):
    # Get a list of all movie IDs
    movie_ids = ratings['movie_id'].unique()
    
    # Predict ratings for all movies the user hasn't rated yet
    user_ratings = {movie_id: algo.predict(movie_name, movie_id).est for movie_id in movie_ids}
    
    # Sort the movies by predicted rating
    recommended_movies = sorted(user_ratings.items(), key=lambda x: x[1], reverse=True)
    
    # Get the top N recommended movies
    top_movies = [movie_id for movie_id, rating in recommended_movies[:num_recommendations]]
    
    # Map movie IDs to titles
    movie_titles = ratings.set_index('movie_id').loc[top_movies]['movie_name'].values
    
    return movie_titles

# Example usage
movie_name = 1
recommendations = get_recommendations(movie_name)
print(recommendations)
