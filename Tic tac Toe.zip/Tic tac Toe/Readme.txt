This is the tic tac toe game. I have kept it simple sticking to python language.
use 
[0,0] to domain [2,2] to mark.
~swarad Gujarathi